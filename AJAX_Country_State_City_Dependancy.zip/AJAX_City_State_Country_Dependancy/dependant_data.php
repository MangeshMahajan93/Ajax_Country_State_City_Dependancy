<?php
$conn=mysqli_connect('localhost','root','','world_table');
if(!$conn)
{
	echo"ERROR";
}

ini_set('display_errors',1);
error_reporting(E_ALL); 
if(isset($_POST['selected']))
{
$cname=$_POST['selected'];

echo $sql1 = "select * from states where country_id='$cname'";   
$result1= mysqli_query($conn ,$sql1);
$option="";
$option.= '<option value="">--Select--</option>';
            while($s = mysqli_fetch_array($result1)){ 
            $option .= '<option value="'.$s['id'].'">'.$s['name'].'</option>';
            }
             
    
}
if(isset($_POST['selected']) && isset($_POST['selected1']))
{
//$cname=$_POST['selected'];
$sname=$_POST['selected1'];

echo $sql1 = "select * from cities where state_id='$sname'";   
$result1= mysqli_query($conn,$sql1);
$option="";
$option.= '<option value="">--Select--</option>';
            while($s = mysqli_fetch_array($result1)){ 
            $option .= '<option value="'.$s['id'].'">'.$s['name'].'</option>';
            }
             
    
}
 echo $option;
?>
