<?php
$conn=mysqli_connect('localhost','root','','world_table');
if(!$conn)
{
	echo"ERROR";
}
?>

<script src="js/jquery-1.2.1.min.js" type="text/javascript"></script>
<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
<script src="js/jquery-1.11.0.min.js"></script>
<script>
function createstate()
				{
				    alert();
					var country="country";
					var selected=document.getElementById(country).value;
					var state="#state";
					$.ajax({
                        url: "dependant_data.php",
                        method: "post",
                        data: {selected:selected},
                        success: function(data){
                            //$(output).append(data);
                            alert(data);
                           $(state).html(data);
                             
                       
                        }
});
				}    
				function createcity()
				{
				    
			    	var country="country";
					var selected=document.getElementById(country).value;
					var state="state";
					var selected1=document.getElementById(state).value;
					var city="#city";
					$.ajax({
                        url: "dependant_data.php",
                        method: "post",
                        data: {selected:selected,selected1:selected1},
                        success: function(data){
                            //$(output).append(data);
                            alert(data);
                           $(city).html(data);
                             
                       
                        }
});
				}    
</script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">   
<section class="content-header">
<h1>Country Wise</h1>
</section>
<section class="content">
<form name ="purchaseform" class="form-horizontal"  method="post">      
<div class="row">
<div class="col-xs-12">
<div class="box">
    <div class="box-header">
      <div class="box-header with-border">
               
            </div>
    </div>


          <div class="box-body table-responsive no-padding">
             
                                                 
                        <select class='form-control' name='country' id='country' onChange="return createstate();">
                          <option value="">---Select---</option>
                            <?php
                            $sql1 = "select * from countries";       
                            $result1 =mysqli_query($conn,$sql1);
                              while($row = mysqli_fetch_array($result1))   
                                 {  
                            ?>
                          <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                          <?php
                            }
                          ?>
                         </select>
                      

                        <select class='form-control' name='state' id='state' onChange="return createcity();">
                          <option value="">---Select---</option>
                            
                         </select>
                                                   
                        <select class='form-control' name='city' id='city'>
                          <option value="">---Select---</option>
                         </select>
                      
  </div>
  <br>

         
</div>
</div>
</div>
</form>
</section>
</div>

